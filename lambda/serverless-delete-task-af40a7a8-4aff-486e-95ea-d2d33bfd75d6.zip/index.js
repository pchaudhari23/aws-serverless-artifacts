const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB({region: 'ap-south-1', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    const params = {
            Key: {
                "TASKID": {
                    S: event.taskid
                }
            },
            TableName: 'task-management-serverless'
        };
        
        // Call DynamoDB to get single item from the table
        dynamoDB.deleteItem(params, function(err, data) {
            if (err) {
                console.log("Error", err);
                callback(err);
            } else {
                console.log("Success", data);
                callback(null,data);
            }
        });
    
    //   callback(null,'Hello from delete tasks');
};


//--------------------------------------------------------------------------

// exports.handler = async (event) => {
//   // TODO implement
//   const response = {
//     statusCode: 200,
//     body: JSON.stringify('Hello from Lambda!'),
//   };
//   return response;
// };