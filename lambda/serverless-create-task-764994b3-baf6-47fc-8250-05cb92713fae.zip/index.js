const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB({region: 'ap-south-1', apiVersion: '2012-08-10'});

exports.handler  = (event, context, callback) => {
  var params = {
    TableName: 'task-management-serverless',
    Item: {
      'TASKID': {S: "Task_"+Math.floor(1000 + Math.random() * 9000)},
      'TITLE' : {S: event.task_title},
      'DESCRIPTION' : {S: event.task_description},
      'PRIORITY': {S: event.task_priority},
      'STATUS': {S: event.task_status},
      'END DATE': {S: event.task_enddate},
      'TEAM SIZE': {N: "" + event.task_teamsize}
    }
  };

  // Call DynamoDB to add the item to the table
  dynamoDB.putItem(params, function(err, data) {
    if (err) {
      console.log("Error", err);
      callback(err);
    } else {
      console.log("Success", data);
      callback(null,data);
    }
  });

};


//--------------------------------------------------------------------------

// exports.handler = async (event) => {
//   // TODO implement
//   const response = {
//     statusCode: 200,
//     body: JSON.stringify('Hello from Lambda!'),
//   };
//   return response;
// };
