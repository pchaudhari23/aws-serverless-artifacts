const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB({region: 'ap-south-1', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    const type = event.type;
    if(type === 'all') {
        const params = {
            TableName: 'task-management-serverless'
        };

        // Call DynamoDB to get all the items from the table
        dynamoDB.scan(params, function(err, data) {
            if (err) {
                console.log("Error", err);
                callback(err);
            } else {
                console.log("Success", data);
                const items = data.Items.map(
                    (dataField) => {
                        return {
                            id: dataField.TASKID.S,
                            title: dataField.TITLE.S,
                            description: dataField.DESCRIPTION.S,
                            status: dataField.STATUS.S,
                            priority: dataField.PRIORITY.S,
                            enddate: dataField['END DATE'].S,
                            teamsize: +dataField['TEAM SIZE'].N,
                        };
                    }
                );
                callback(null,items);
            }
        });
    } else if(type === 'single') {
        
        const params = {
            Key: {
                "TASKID": {
                    S: "Task_3542"
                }
            },
            TableName: 'task-management-serverless'
        }
        
        // Call DynamoDB to get single item from the table
        dynamoDB.getItem(params, function(err, data) {
            if (err) {
                console.log("Error", err);
                callback(err);
            } else {
                console.log("Success", data);
                callback(null,
                    [{
                        id: data.Item.TASKID.S,
                        title: data.Item.TITLE.S,
                        description: data.Item.DESCRIPTION.S,
                        status: data.Item.STATUS.S,
                        priority: data.Item.PRIORITY.S,
                        enddate: data.Item['END DATE'].S,
                        teamsize: +data.Item['TEAM SIZE'].N,
                    }]
                );
            }
        });       
    } else {
        callback('Something went very wrong');    
    }
};


//--------------------------------------------------------------------------

// exports.handler = async (event) => {
//   // TODO implement
//   const response = {
//     statusCode: 200,
//     body: JSON.stringify('Hello from Lambda!'),
//   };
//   return response;
// };